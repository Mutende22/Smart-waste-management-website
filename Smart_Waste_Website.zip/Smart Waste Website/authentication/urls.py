from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('home', views.home, name="home"),
    path('signup', views.signup, name="signup"),
    path('sign_in', views.sign_in, name="sign_in"),
    path('signout', views.signout, name="signout"),
    path('contact', views.contact, name="contact"),
    path('services', views.services, name="services"),
    path('faq', views.faq, name="faq"),
    path('about', views.about, name="about"), 
    path('admin', views.admin, name="admin"),
    path('monitor', views.monitor, name="monitor"),
]
