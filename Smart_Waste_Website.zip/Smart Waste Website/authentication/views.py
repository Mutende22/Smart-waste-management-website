from django.shortcuts import redirect, render
from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from bin import settings
from django.core.mail import send_mail
from django.conf import settings
# from .models import CustomUser 

# Create your views here.
def home(request):
    return render(request, "authenticate/index.html")

def signup(request):
    if request.method =='POST':
        username = request.POST.get('username')
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        email = request.POST.get('email')
        pass1 = request.POST.get('pass1')
        pass2 = request.POST.get('pass2')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists! Please try another username")
            return redirect('home')
        
        if len(username) > 10:
            messages.error(request, "Username must be less than 10 characters")
            return redirect('home')
            
        if len(pass1) < 6:
            messages.error(request, "Password must be at least 6 characters long")
            return redirect('home')
        
        if pass1 != pass2:
            messages.error(request, "Passwords did not match!")
            return redirect('home')
            
        if not username.isalnum():
            messages.error(request, "Username must be Alpha-Numeric!")
            return redirect('home')
        
        my_user = User.objects.create_user(username, email, pass1)
        my_user.first_name = fname
        my_user.last_name = lname
        my_user.save()
        
        messages.success(request, "Your account has been successfully created. We have sent you a confirmation email.")
        
        # Welcome email
        subject = "Welcome to Bintelligent Waste Solutions!"
        message = f"Hello {my_user.first_name}!\nWelcome to Bintelligent Waste Solutions!\nThank you for visiting our website. We have also sent you a confirmation email. Please confirm your email address in order to activate your account.\n\nThank You.\nBintelligent Support Team"
        from_email = settings.EMAIL_HOST_USER
        to_list = [my_user.email]
        send_mail(subject, message, from_email, to_list, fail_silently=True)
        
        return redirect('sign_in')
    
    return render(request, "authenticate/signup.html")

def sign_in(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            # Redirect to a success page.
            return redirect('home')  # Replace 'home' with the name of your home page URL pattern
        else:
            # Return an 'invalid login' error message.
            messages.error(request, 'Invalid username or password.')
            return redirect('sign_in')  # Replace 'sign_in' with the name of your sign-in page URL pattern

    return render(request, 'authentication/sign_in.html')

def signout(request):
    logout(request)
    messages.success(request, "Logged Out Successfully!")
    return redirect('home')


def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        data = {
            'name': name,
            'email': email,
            'subject': subject
        }
        mail_subject = '''
        New Message: {}
        
        From: {}
        '''.format(data['subject'], data['email'])

        send_mail(data['name'], mail_subject, '', ['vannymutende22@gmail.com'])
        messages.success(request, 'Your message has been sent successfully!')
        # # Or any appropriate response 
    return render(request, 'authenticate/contact.html')
        #     name, #title
        #     subject, #subject
        #     'settings.EMAIL_HOST_USER', #sender if not available considered the default
        #     [email], #receiver email
        # fail_silently=False) 
        # return render(request, 'authenticate/contact.html')
        # return HttpResponse("authenticate/contact.html")
#  data = {
        #     'name': name,
        #     'email': email,
        #     'subject': subject 
        # }
        # subject = '''
        # New Message: {}
        
        # From: {}
        # '''.format(data['subject'], data['email'])
        #     data['name'], subject, '', ['vannymutende22@gmail.com'] 
        # )
            # name, #title
            # subject, #subject
            # 'settings.EMAIL_HOST_USER', #sender if not available considered the default
            # [email], #receiver email


def faq(request):
    return render(request, "authenticate/faq.html")

def about(request):
    return render(request, "authenticate/about.html")

def services(request):
    return render(request, "authenticate/services.html")

def admin(request):
    return render(request, "authenticate/admin.html")

def monitor(request):
    return render(request, "authenticate/monitor.html")

