document.addEventListener('DOMContentLoaded', function() {
    var accordions = document.querySelectorAll('.accordion');

    accordions.forEach(function(accordion) {
        accordion.addEventListener('click', function() {
            // Toggle the active class for the clicked FAQ item
            this.classList.toggle('active');

            // Toggle the visibility of the corresponding answer panel
            var panel = this.nextElementSibling;
            if (panel.style.maxHeight) {
                panel.style.maxHeight = null;
            } else {
                panel.style.maxHeight = panel.scrollHeight + 'px';
            }
        });
    });
});
